"""Current version of package keras_synthetic_genome_sequence"""
__version__ = "1.1.4"
