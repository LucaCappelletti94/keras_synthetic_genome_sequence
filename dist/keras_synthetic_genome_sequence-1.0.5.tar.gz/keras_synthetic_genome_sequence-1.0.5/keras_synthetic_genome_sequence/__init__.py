from .gap_sequence import GapSequence
from .single_gap_sequence import SingleGapSequence

__all__ = ["GapSequence", "SingleGapSequence"]
