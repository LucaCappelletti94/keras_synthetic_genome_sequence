from .gap_sequence import GapSequence

__all__ = ["GapSequence"]
